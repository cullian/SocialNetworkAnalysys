/**
 * @author William Cullian
 *
 */
package graph;
public interface Data {
}
