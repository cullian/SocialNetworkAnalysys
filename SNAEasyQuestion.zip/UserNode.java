/**
 * @author William Cullian
 * 
 * A class which represents a map node(person) in a 
 * MapGraph object connected to other nodes by edges(friendships).
 * The MapNode contains the user number and a
 * list of edges(friendships) that connect it to other 
 * nodes(people).  It is being used to represent a 
 * social network.
 *
 */
package graph;

import java.util.LinkedList;
import java.util.List;

class UserNode {
	private int userNumber;				// number of person
	private List<FriendshipEdge> friendships;	// list of friends of this person
	
	/**
	 * Constructor sets user number with empty edge list
	 * @param loc
	 */
	public UserNode(int num) {
		super();
		this.userNumber = num;
		this.friendships = new LinkedList<FriendshipEdge>();
	}

	/**
	 * Add an edge to the edges list if it does not 
	 * already exist
	 * @param add newEdge to list
	 * @return true if edge added
	 */
	public boolean addFriend(FriendshipEdge newEdge) {
		// if friendships contains new edge
		for (FriendshipEdge friendshipEdge : friendships) {
			if (friendshipEdge.getTo() == newEdge.getTo() && friendshipEdge.getFrom() == newEdge.getFrom()) {
				return false;
			}
		}
		// else add edge
		friendships.add(newEdge);
		return true;
	}

	@Override
	public String toString() {
		return "Node [userNumber=" + userNumber + ", friendships=" + friendships + "]";
	}

	public List<FriendshipEdge> getFriends() {
		return new LinkedList<FriendshipEdge>(friendships);
	}

	public int getUserNumber() {
		return userNumber;
	}


}
