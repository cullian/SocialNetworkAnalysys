/**
 * @author William Cullian
 * 
 * A class which represents a map edge(friendship) connecting two
 * nodes(people) in the CapGraph Object.  These are 
 * directional edges, so a friendship will require two
 * edges.  The Class contains the from node's user number 
 * as well as the to node's user number.
 *
 */
package graph;

class FriendshipEdge {
	private int from;
	private int to;
	
	/**
	 * Constructor
	 * 
	 * @param from - user number of from node
	 * @param to - user number of to node
	 */
	public FriendshipEdge(int from, int to) {
		super();
		this.from = from;
		this.to = to;
	}

	@Override
	public String toString() {
		return "FriendshipEdge [from=" + from + ", to=" + to + "]";
	}

	/**
	 * Getter for from node location
	 * @return the from
	 */
	public int getFrom() {
		return from;
	}

	/**
	 * Getter for to node location
	 * @return the to
	 */
	public int getTo() {
		return to;
	}


}
