/**
 * Egonet is a graph class designed to hold egonets and stats on them
 */
package graph;

import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Stack;

import util.GraphLoader;

/**
 * @author William Cullian
 *
 */
public class Egonet implements Graph{

	// map of user numbers mapped to CapNodes for respective people.
	private Map<Integer, UserNode> people;
	private int numPeople;
	private int numFriendships;
	private int centralEgoUser;
	private int egonetDepth;
	private double friendshipConnectivityStrength;
	
	/** 
	 * Create a new empty Egonet 
	 */
	public Egonet(int user)
	{
		super();
		this.people = new HashMap<Integer, UserNode>();
		this.numPeople = 0;
		this.numFriendships = 0;
		this.centralEgoUser = user;
		this.egonetDepth = 0;
		this.friendshipConnectivityStrength = 0.0;
		this.addFriend(user);
	}
	
	/**
	 * Get the number of people in the graph
	 * @return The number of people in the graph.
	 */
	public int getNumPeople()
	{
		return numPeople;
	}
	
	/**
	 * Return the people, which are the vertices in this graph.
	 * @return The vertices in this graph as a set of integers
	 */
	public Set<Integer> getPeople()
	{		
		return people.keySet();
	}
	
	/**
	 * Get the number of friendships in the graph
	 * @return The number of friendships / 2 .
	 */
	public int getNumFriendships()
	{
		return numFriendships / 2;
	}

	/**
	 * Get the user for whom this egonet was created
	 * @return the centralEgoUser
	 */
	public int getCentralEgoUser() {
		return centralEgoUser;
	}

	/**
	 * @return the egonetDepth
	 */
	public int getEgonetDepth() {
		return egonetDepth;
	}

	/**
	 * @param egonetDepth the egonetDepth to set
	 */
	public void setEgonetDepth(int egonetDepth) {
		this.egonetDepth = egonetDepth;
	}

	/**
	 * Get the connectivity strength of the egonet
	 * @return the friendshipConnectivityStrength
	 */
	public double getFriendshipConnectivityStrength() {
		return friendshipConnectivityStrength;
	}

	
	/** 
	 * Prints all the vertices and their respective edge lists
	 * for debugging purposes
	 */
	@Override
	public void printGraph() {
		System.out.println("Egonet for user: " + centralEgoUser);
		System.out.println("Number of people in graph: " + numPeople);
		System.out.println("Number of friendships in graph: " + numFriendships);
		System.out.println("Connectivity strength of graph: " + friendshipConnectivityStrength);
		for (UserNode node : people.values()) {
			System.out.println(node);
		}
	}

	/** 
	 * Prints the number of people and the number of friendships 
	 * for debugging purposes
	 */
	public void printStats() {
		System.out.println("Egonet for user: " + centralEgoUser);
		System.out.println("Egonet depth: " + egonetDepth);
		System.out.println("Number of people in graph: " + numPeople);
		System.out.println("Number of friendships in graph: " + numFriendships / 2);
		System.out.println("Maximum possible number of friendships in graph: " + ((double)numPeople * (numPeople - 1)) / 2);
		System.out.println("Connectivity strength of graph: " + friendshipConnectivityStrength);
	}

	/** Add a node corresponding to an person mapped to the person number
	 * If the person is already in the graph, this method does 
	 * not change the graph.
	 * @param num  The number of the person.
	 */
	/* (non-Javadoc)
	 * @see graph.Graph#addVertex(int)
	 */
	@Override
	public void addFriend(int num) {
		// if person is not in people list
		if (!people.containsKey(num)) {
			// put it in the list and count it
			people.put(num, new UserNode(num));
			numPeople++;
			recalculateFCS();
		}
	}
	

	private void recalculateFCS() {
		if (numPeople < 2) {
			return;
		}
		friendshipConnectivityStrength = (double)numFriendships / (((double)numPeople * (numPeople - 1)));
		
	}

	/**
	 * Adds a directed edge to the graph from person number 1 to person number 2.  
	 * Precondition: Both people have already been added to the graph
	 * If the people numbers do not exist in the graph, it does nothing
	 * @param from The starting point of the edge
	 * @param to The ending point of the edge
	 */
	/* (non-Javadoc)
	 * @see graph.Graph#addEdge(int, int)
	 */
	@Override
	public void addEdge(int from, int to) {
		// if the people do not exist, return
		if (!people.containsKey(from) || !people.containsKey(to)) {
			return;
		}
		else {
			// create new edge, add it to edge list and count it
			FriendshipEdge newEdge = new FriendshipEdge(from, to);
			if(people.get(from).addFriend(newEdge)){
				numFriendships++;
				recalculateFCS();				
			}
		}
		
	}
	
	/**
	 * This method returns a representation of the graph
	 * @return Hashmap adjacancy list of the graph
	 */
	/* (non-Javadoc)
	 * @see graph.Graph#exportGraph()
	 */
	@Override
	public HashMap<Integer, HashSet<Integer>> exportGraph() {
		// create object to return
		HashMap<Integer, HashSet<Integer>> ret = new HashMap<Integer, HashSet<Integer>>();
		// iterate thru each node
		for (UserNode node : people.values()) {
			// make hashset of nodes neighbors
			HashSet<Integer> neighbors = new HashSet<Integer>();
			for (FriendshipEdge edge : node.getFriends()) {
				neighbors.add(edge.getTo());
			}
			// add node and neighbors to return object
			ret.put(node.getUserNumber(), neighbors);
		}
		return ret;
	}

	public Graph exportEgonet() {
		// create object to return
		Egonet ret = new Egonet(centralEgoUser);
		// iterate thru each node
		for (UserNode node : people.values()) {
			// add nodes to return object
			ret.addFriend(node.getUserNumber());
		}
		// go thru again and add edges
		for (UserNode node : people.values()) {
			for (FriendshipEdge friendship : node.getFriends()) {
				ret.addEdge(friendship.getFrom(), friendship.getTo());
			}
		}
		ret.setEgonetDepth(egonetDepth);
		return ret;
	}

	/**
	 * This method returns a transposed representation of the graph
	 * @return Hashmap adjacancy list of the transposed graph
	 */
	public HashMap<Integer, HashSet<Integer>> exportTranspose() {
		// create object to return
		HashMap<Integer, HashSet<Integer>> ret = new HashMap<Integer, HashSet<Integer>>();
		// create new CapGraph with edges reversed
		SocialNetworkGraph transposeGraph = new SocialNetworkGraph();
		// iterate thru each node add all the vertices to transposeGraph
		for (UserNode node : people.values()) {
			int user = node.getUserNumber();
			transposeGraph.addFriend(user);
		}
		// now go thru again and add the edges transposed
		for (UserNode node : people.values()) {
			for (FriendshipEdge edge : node.getFriends()) {
				transposeGraph.addEdge(edge.getTo(), edge.getFrom());
			}
		}
		ret = transposeGraph.exportGraph();
		return ret;
	}


}
